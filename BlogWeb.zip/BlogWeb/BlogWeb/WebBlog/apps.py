from django.apps import AppConfig


class WebblogConfig(AppConfig):
    name = 'WebBlog'
