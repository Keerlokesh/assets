from sqlite3.dbapi2 import Date

from django.http import HttpResponse
from django.shortcuts import render
from django.urls import include
from .models import Blogpost


def index(request):
    Blog = Blogpost.objects.all()

    return render(request,'index.html',{'blogs':Blog})

def blog(request,id):
    post = Blogpost.objects.filter(post_id=id)[0]
    print(post)
    return render(request,'blogpost.html',{'post':post})