from django.http import HttpResponse
from django.shortcuts import render
from django.urls import include


def index(request):
    return render(request,'index.html')

def blog(request):
    return render(request,'blogpost.html')